This folder contains 20 BACE crystallographic structures used in the GC4 challenge. Files are named to match the corresponding cocrystallized ligand.
